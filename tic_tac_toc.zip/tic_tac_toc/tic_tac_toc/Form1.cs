using System.Diagnostics.Metrics;
using System.Numerics;

namespace tic_tac_toc
{
    public partial class Form1 : Form
    {
       // public int counter = 1;
        public int Turn = 1;
        public int Count_Matrix_spaces = 0;
       // public bool win_know = false;

        //variables that counts the wins of each Player
        public int counter_Play1_Win = 0;
        public int counter_Play2_Win = 0;

        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        //------------------------Functions that paint buttons in blue-----------------------
        /// </summary>
        //Paint first row buttons, from btn1 to btn3. HORIZONTAL
        public void Paint_Buttons1_3() {
            btn1_Matrix.BackColor = Color.Blue;
            btn1_Matrix.ForeColor = Color.White;
            btn2_Matrix.BackColor = Color.Blue;
            btn2_Matrix.ForeColor = Color.White;
            btn3_Matrix.BackColor = Color.Blue;
            btn3_Matrix.ForeColor = Color.White;
        }

        //Paint buttons of first row first column, from btn1 to btn7. VERTICAL
        public void Paint_Buttons1_7()
        {
            btn1_Matrix.BackColor = Color.Blue;
            btn1_Matrix.ForeColor = Color.White;
            btn4_Matrix.BackColor = Color.Blue;
            btn4_Matrix.ForeColor = Color.White;
            btn7_Matrix.BackColor = Color.Blue;
            btn7_Matrix.ForeColor = Color.White;
        }

        //Paint buttons of first row second column, from btn2 to btn8. VERTICAL
        public void Paint_Buttons2_8()
        {
            btn2_Matrix.BackColor = Color.Blue;
            btn2_Matrix.ForeColor = Color.White;
            btn5_Matrix.BackColor = Color.Blue;
            btn5_Matrix.ForeColor = Color.White;
            btn8_Matrix.BackColor = Color.Blue;
            btn8_Matrix.ForeColor = Color.White;
        }

        //Paint buttons of first row third column, from btn3 to btn9. VERTICAL
        public void Paint_Buttons3_9()
        {
            btn3_Matrix.BackColor = Color.Blue;
            btn3_Matrix.ForeColor = Color.White;
            btn6_Matrix.BackColor = Color.Blue;
            btn6_Matrix.ForeColor = Color.White;
            btn9_Matrix.BackColor = Color.Blue;
            btn9_Matrix.ForeColor = Color.White;
        }

        //Paint second row buttons, from btn4 to btn6. HORIZONTAL
        public void Paint_Buttons4_6()
        {
            btn4_Matrix.BackColor = Color.Blue;
            btn4_Matrix.ForeColor = Color.White;
            btn5_Matrix.BackColor = Color.Blue;
            btn5_Matrix.ForeColor = Color.White;
            btn6_Matrix.BackColor = Color.Blue;
            btn6_Matrix.ForeColor = Color.White;
        }

        //Paint third row buttons, from btn7 to btn9. horizontal
        public void Paint_Buttons7_9()
        {
            btn7_Matrix.BackColor = Color.Blue;
            btn7_Matrix.ForeColor = Color.White;
            btn8_Matrix.BackColor = Color.Blue;
            btn8_Matrix.ForeColor = Color.White;
            btn9_Matrix.BackColor = Color.Blue;
            btn9_Matrix.ForeColor = Color.White;
        }

        ///Paints diagonal buttons from btn1 - btn9. DIAGONAL
        public void Paint_Buttons1_9()
        {
            btn1_Matrix.BackColor = Color.Blue;
            btn1_Matrix.ForeColor = Color.White;
            btn5_Matrix.BackColor = Color.Blue;
            btn5_Matrix.ForeColor = Color.White;
            btn9_Matrix.BackColor = Color.Blue;
            btn9_Matrix.ForeColor = Color.White;
        }

        //Paints diagonal buttons from btn3 - btn7
        public void Paint_Buttons3_7()
        {
            btn3_Matrix.BackColor = Color.Blue;
            btn3_Matrix.ForeColor = Color.White;
            btn5_Matrix.BackColor = Color.Blue;
            btn5_Matrix.ForeColor = Color.White;
            btn7_Matrix.BackColor = Color.Blue;
            btn7_Matrix.ForeColor = Color.White;
        }

        public void Check_is_Draw()
        {
            if (Count_Matrix_spaces == 9)
            {
                MessageBox.Show("This game is a Draw, Reset and Play Again");
                return;                
            }
         }

        //---------Evento Click en todos los botones-----------------------------
        private void btn1_Matrix_Click(object sender, EventArgs e)
        {
            // The variable turn checks whether it will be player 1's turn (odd turn) or player 2's turn(even turn).          
            if (Turn % 2 != 0)
            {
                btn1_Matrix.Text = "X";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();
            }
            else
            {               
                btn1_Matrix.Text = "O";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();

            }
            //Check if there are 3 positions with the same symbol, from right to left and vice versa. HORIZONTAL
            if (btn1_Matrix.Text == btn2_Matrix.Text && btn2_Matrix.Text == btn3_Matrix.Text)
            {
                if (btn1_Matrix.Text == "X")
                {
                    Paint_Buttons1_3();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();   
                   

                }
                else if (btn1_Matrix.Text == "O")
                {
                    Paint_Buttons1_3();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                   
                }
            }
            //Check from button 1 to button 7, from bottom to top and vice versa. VERTICAL 1-7
            else if (btn1_Matrix.Text == btn4_Matrix.Text && btn4_Matrix.Text == btn7_Matrix.Text && btn1_Matrix.Text != "")
            {
                if (btn1_Matrix.Text == "X" | btn4_Matrix.Text == "X" | btn7_Matrix.Text == "X")
                {
                    Paint_Buttons1_7();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                    

                }
                else if (btn1_Matrix.Text == "O" | btn4_Matrix.Text == "O" | btn7_Matrix.Text == "O")
                {
                    Paint_Buttons1_7();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }

            //Check from button 1 to button 9, from bottom to top and vice versa. DIAGONAL 1-9
            else if (btn1_Matrix.Text == btn5_Matrix.Text && btn5_Matrix.Text == btn9_Matrix.Text && btn1_Matrix.Text != "")
            {
                if (btn1_Matrix.Text == "X" | btn5_Matrix.Text == "X" | btn9_Matrix.Text == "X")
                {
                    Paint_Buttons1_9();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                    

                }
                else if (btn1_Matrix.Text == "O" | btn5_Matrix.Text == "O" | btn9_Matrix.Text == "O")
                {
                    Paint_Buttons1_9();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                   
                }
            }           
        }

        private void btn2_Matrix_Click(object sender, EventArgs e)
        {          
            if (Turn % 2 != 0)
            {               
                btn2_Matrix.Text = "X";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();
            }
            else
            {
                btn2_Matrix.Text = "O";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();
            }
            //Check if there are 3 positions with the same symbol, from right to left and vice versa.
            if (btn1_Matrix.Text == btn2_Matrix.Text && btn2_Matrix.Text == btn3_Matrix.Text)
            {
                if (btn2_Matrix.Text == "X")
                {
                    Paint_Buttons1_3();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                    

                }
                else if (btn2_Matrix.Text == "O")
                {
                    Paint_Buttons1_3();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                   

                }
            }
            //checks from button 2 to button 8 and vice versa HORIZONTAL 2-8
            else if (btn2_Matrix.Text == btn5_Matrix.Text && btn5_Matrix.Text == btn8_Matrix.Text && btn2_Matrix.Text != "")
            {
                if (btn2_Matrix.Text == "X" | btn5_Matrix.Text == "X" | btn8_Matrix.Text == "X")
                {
                    Paint_Buttons2_8();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                    

                }
                else if (btn2_Matrix.Text == "O" | btn5_Matrix.Text == "O" | btn8_Matrix.Text == "O")
                {
                    Paint_Buttons2_8();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Turn % 2 != 0)
            {               
                btn3_Matrix.Text = "X";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();
            }
            else
            {
                btn3_Matrix.Text = "O";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();

            }
                //Check if there are 3 positions with the same symbol, from right to left and vice versa.

                if (btn1_Matrix.Text == btn2_Matrix.Text && btn2_Matrix.Text == btn3_Matrix.Text)
                {
                    if (btn3_Matrix.Text == "X")
                    {
                        Paint_Buttons1_3();
                        counter_Play1_Win++;
                        MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                        lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                       
                    }
                    else if (btn3_Matrix.Text == "O")
                    {
                        Paint_Buttons1_3();
                        counter_Play2_Win++;
                        MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                        lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                        
                    }
                }

                //Check if 3 positions with the same symbol, from top to bottom. horizontal 3-9
                else if (btn3_Matrix.Text == btn6_Matrix.Text && btn6_Matrix.Text == btn9_Matrix.Text && btn3_Matrix.Text != "")
                {
                    if (btn3_Matrix.Text == "X" | btn6_Matrix.Text == "X" | btn9_Matrix.Text == "X")
                    {
                        Paint_Buttons3_9();
                        counter_Play1_Win++;
                        MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                        lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                       
                    }
                    else if (btn3_Matrix.Text == "O" | btn6_Matrix.Text == "O" | btn9_Matrix.Text == "O")
                    {
                        Paint_Buttons3_9();
                        counter_Play2_Win++;
                        MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                        lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                        
                    }
                }
                //Check from button 3 to button 7, from bottom to top and vice versa. DIAGONAL 3-7
                else if (btn3_Matrix.Text == btn5_Matrix.Text && btn5_Matrix.Text == btn7_Matrix.Text && btn3_Matrix.Text != "")
                {
                    if (btn3_Matrix.Text == "X" | btn5_Matrix.Text == "X" | btn7_Matrix.Text == "X")
                    {
                        Paint_Buttons3_7();
                        counter_Play1_Win++;
                        MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                        lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                        
                    }
                    else if (btn3_Matrix.Text == "O" | btn5_Matrix.Text == "O" | btn7_Matrix.Text == "O")
                    {
                        Paint_Buttons3_7();
                        counter_Play2_Win++;
                        MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                        lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                       
                    }
                }

            }
        



        private void btn4_Matrix_Click(object sender, EventArgs e)
        {
            if (Turn % 2 != 0)
            {
                btn4_Matrix.Text = "X";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();
            }
            else
            {
                btn4_Matrix.Text = "O";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();
            }
            //Check if there are 3 positions with the same symbol, from right to left and vice versa.
            if (btn4_Matrix.Text == btn5_Matrix.Text && btn5_Matrix.Text == btn6_Matrix.Text)
            {
                if (btn4_Matrix.Text == "X")
                {
                    Paint_Buttons4_6();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                    
                }
                else if (btn4_Matrix.Text == "O")
                {
                    Paint_Buttons4_6();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }

            //Check from button 1 to button 7, from bottom to top and vice versa. HORIZONTAL 1-7
            else if (btn1_Matrix.Text == btn4_Matrix.Text && btn4_Matrix.Text == btn7_Matrix.Text && btn1_Matrix.Text != "")
            {
                if (btn1_Matrix.Text == "X" | btn4_Matrix.Text == "X" | btn7_Matrix.Text == "X")
                {
                    Paint_Buttons1_7();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                    
                }
                else if (btn1_Matrix.Text == "O" | btn4_Matrix.Text == "O" | btn7_Matrix.Text == "O")
                {
                    Paint_Buttons1_7();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }          
        }

        private void btn5_Matrix_Click(object sender, EventArgs e)
        {
          
            if (Turn % 2 != 0)
            {
                btn5_Matrix.Text = "X";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();
            }
            else
            {
                btn5_Matrix.Text = "O";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();
            }

            //Check if there are 3 positions with the same symbol, from right to left and vice versa.
            if (btn4_Matrix.Text == btn5_Matrix.Text && btn5_Matrix.Text == btn6_Matrix.Text)
            {
                if (btn5_Matrix.Text == "X")
                {
                    Paint_Buttons4_6();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                   
                }
                else if (btn5_Matrix.Text == "O")
                {
                    Paint_Buttons4_6();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }

            //checks from button 2 to button 8 and vice versa HORIZONTAL 2-8
            else if (btn2_Matrix.Text == btn5_Matrix.Text && btn5_Matrix.Text == btn8_Matrix.Text && btn2_Matrix.Text != "")
            {
                if (btn2_Matrix.Text == "X" | btn5_Matrix.Text == "X" | btn8_Matrix.Text == "X")
                {
                    Paint_Buttons2_8();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                    
                }
                else if (btn2_Matrix.Text == "O" | btn5_Matrix.Text == "O" | btn8_Matrix.Text == "O")
                {
                    Paint_Buttons2_8();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }

            //Check from button 1 to button 9, from bottom to top and vice versa. DIAGONAL 1-9
            else if (btn1_Matrix.Text == btn5_Matrix.Text && btn5_Matrix.Text == btn9_Matrix.Text && btn1_Matrix.Text != "")
            {
                if (btn1_Matrix.Text == "X" | btn5_Matrix.Text == "X" | btn9_Matrix.Text == "X")
                {
                    Paint_Buttons1_9();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                    
                }
                else if (btn1_Matrix.Text == "O" | btn5_Matrix.Text == "O" | btn9_Matrix.Text == "O")
                {
                    Paint_Buttons1_9();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }

            //Check from button 3 to button 7, from bottom to top and vice versa. DIAGONAL 3-7
            else if (btn3_Matrix.Text == btn5_Matrix.Text && btn5_Matrix.Text == btn7_Matrix.Text && btn3_Matrix.Text != "")
            {
                if (btn3_Matrix.Text == "X" | btn5_Matrix.Text == "X" | btn7_Matrix.Text == "X")
                {
                    Paint_Buttons3_7();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                    
                }
                else if (btn3_Matrix.Text == "O" | btn5_Matrix.Text == "O" | btn7_Matrix.Text == "O")
                {
                    Paint_Buttons3_7();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }
           
        }

        private void btn6_Matrix_Click(object sender, EventArgs e)
        {
            if (Turn % 2 != 0)
            {
                btn6_Matrix.Text = "X";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();
            }
            else
            {
                btn6_Matrix.Text = "O";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();
            }

            //Check if there are 3 positions with the same symbol, from right to left and vice versa.
            if (btn4_Matrix.Text == btn5_Matrix.Text && btn5_Matrix.Text == btn6_Matrix.Text)
            {
                if (btn6_Matrix.Text == "X")
                {
                    Paint_Buttons4_6();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                   
                }
                else if (btn6_Matrix.Text == "O")
                {
                    Paint_Buttons4_6();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }
            //checks from button 2 to button 8 and vice versa VERTICAL 3-9
            else if (btn3_Matrix.Text == btn6_Matrix.Text && btn6_Matrix.Text == btn9_Matrix.Text && btn6_Matrix.Text != "")
            {
                if (btn3_Matrix.Text == "X" | btn6_Matrix.Text == "X" | btn9_Matrix.Text == "X")
                {
                    Paint_Buttons3_9();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                   
                }
                else if (btn3_Matrix.Text == "O" | btn6_Matrix.Text == "O" | btn9_Matrix.Text == "O")
                {
                    Paint_Buttons3_9();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                   
                }
            }
            
        }

        private void btn7_Matrix_Click(object sender, EventArgs e)
        {

            if (Turn % 2 != 0)
            {
               
                btn7_Matrix.Text = "X";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();
            }
            else
            {
               
                btn7_Matrix.Text = "O";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();
            }

            //Check if there are 3 positions with the same symbol, from right to left and vice versa.
            if (btn7_Matrix.Text == btn8_Matrix.Text && btn8_Matrix.Text == btn9_Matrix.Text)
            {
                if (btn7_Matrix.Text == "X")
                {
                    Paint_Buttons7_9();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                    
                }
                else if (btn7_Matrix.Text == "O")
                {
                    Paint_Buttons7_9();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }

            //Check from button 1 to button 7, from bottom to top and vice versa. VERTICAL 1-7
            else if (btn1_Matrix.Text == btn4_Matrix.Text && btn4_Matrix.Text == btn7_Matrix.Text && btn1_Matrix.Text != "")
            {
                if (btn1_Matrix.Text == "X" | btn4_Matrix.Text == "X" | btn7_Matrix.Text == "X")
                {
                    Paint_Buttons1_7();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                    
                }
                else if (btn1_Matrix.Text == "O" | btn4_Matrix.Text == "O" | btn7_Matrix.Text == "O")
                {
                    Paint_Buttons1_7();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }
            //Check from button 3 to button 7, from bottom to top and vice versa. DIAGONAL 3-7
            else if (btn3_Matrix.Text == btn5_Matrix.Text && btn5_Matrix.Text == btn7_Matrix.Text && btn3_Matrix.Text != "")
            {
                if (btn3_Matrix.Text == "X" | btn5_Matrix.Text == "X" | btn7_Matrix.Text == "X")
                {
                    Paint_Buttons3_7();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                   
                }
                else if (btn3_Matrix.Text == "O" | btn5_Matrix.Text == "O" | btn7_Matrix.Text == "O")
                {
                    Paint_Buttons3_7();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }          
        }

        private void btn8_Matrix_Click(object sender, EventArgs e)
        {
           
            if (Turn % 2 != 0)
            {
                
                btn8_Matrix.Text = "X";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();
            }
            else
            {
               
                btn8_Matrix.Text = "O";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();
            }
            //Check if there are 3 positions with the same symbol, from right to left and vice versa.
            if (btn7_Matrix.Text == btn8_Matrix.Text && btn8_Matrix.Text == btn9_Matrix.Text)
            {
                if (btn8_Matrix.Text == "X")
                {
                    Paint_Buttons7_9();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                    
                }
                else if (btn8_Matrix.Text == "O")
                {
                    Paint_Buttons7_9();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }
            //checks from button 2 to button 8 and vice versa VERTICAL 2-8
            else if (btn2_Matrix.Text == btn5_Matrix.Text && btn5_Matrix.Text == btn8_Matrix.Text && btn2_Matrix.Text != "")
            {
                if (btn2_Matrix.Text == "X" | btn5_Matrix.Text == "X" | btn8_Matrix.Text == "X")
                {
                    Paint_Buttons2_8();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                    
                }
                else if (btn2_Matrix.Text == "O" | btn5_Matrix.Text == "O" | btn8_Matrix.Text == "O")
                {
                    Paint_Buttons2_8();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }
           
        }

        private void btn9_Matrix_Click(object sender, EventArgs e)
        {

            if (Turn % 2 != 0)
            {
               
                btn9_Matrix.Text = "X";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();
            }
            else
            {
                
                btn9_Matrix.Text = "O";
                Turn++;
                Count_Matrix_spaces++;
                Check_is_Draw();
            }

            //Check if there are 3 positions with the same symbol, from right to left and vice versa.
            if (btn7_Matrix.Text == btn8_Matrix.Text && btn8_Matrix.Text == btn9_Matrix.Text)
            {
                if (btn9_Matrix.Text == "X")
                {
                    Paint_Buttons7_9();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times"); ;
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                    
                }
                else if (btn9_Matrix.Text == "O")
                {
                    Paint_Buttons7_9();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }
            //checks from button 3 to 9. VERTICAL 3-9.
            else if (btn3_Matrix.Text == btn6_Matrix.Text && btn6_Matrix.Text == btn9_Matrix.Text && btn3_Matrix.Text != "")
            {
                if (btn3_Matrix.Text == "X" | btn6_Matrix.Text == "X" | btn9_Matrix.Text == "X")
                {
                    Paint_Buttons3_9();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                    
                }
                else if (btn3_Matrix.Text == "O" | btn6_Matrix.Text == "O" | btn9_Matrix.Text == "O")
                {
                    Paint_Buttons3_9();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }
            
            //Check from button 1 to button 9, from bottom to top and vice versa. DIAGONAL 1-9
            else if (btn1_Matrix.Text == btn5_Matrix.Text && btn5_Matrix.Text == btn9_Matrix.Text && btn1_Matrix.Text != "")
            {
                if (btn1_Matrix.Text == "X" | btn5_Matrix.Text == "X" | btn9_Matrix.Text == "X")
                {
                    Paint_Buttons1_9();
                    counter_Play1_Win++;
                    MessageBox.Show("The player 1 has won : " + counter_Play1_Win + "  times");
                    lbl_Player1.Text = "Player 1: " + counter_Play1_Win.ToString();
                    
                }
                else if (btn1_Matrix.Text == "O" | btn5_Matrix.Text == "O" | btn9_Matrix.Text == "O")
                {
                    Paint_Buttons1_9();
                    counter_Play2_Win++;
                    MessageBox.Show("The player 2 has won : " + counter_Play2_Win + "  times");
                    lbl_Player2.Text = "Player 2: " + counter_Play2_Win.ToString();
                    
                }
            }
        }

        //event RESET IN BUTTON.
        private void btn_Reset_Click(object sender, EventArgs e)
        {
            btn1_Matrix.Text = "";
            btn2_Matrix.Text = "";
            btn3_Matrix.Text = "";
            btn4_Matrix.Text = "";
            btn5_Matrix.Text = "";
            btn6_Matrix.Text = "";
            btn7_Matrix.Text = "";
            btn8_Matrix.Text = "";
            btn9_Matrix.Text = "";

            btn1_Matrix.BackColor = Color.White;
            btn1_Matrix.ForeColor = Color.Black;
            btn2_Matrix.BackColor = Color.White;
            btn2_Matrix.ForeColor = Color.Black;
            btn3_Matrix.BackColor = Color.White;
            btn3_Matrix.ForeColor = Color.Black;

            btn4_Matrix.BackColor = Color.White;
            btn4_Matrix.ForeColor = Color.Black;
            btn5_Matrix.BackColor = Color.White;
            btn5_Matrix.ForeColor = Color.Black;
            btn6_Matrix.BackColor = Color.White;
            btn6_Matrix.ForeColor = Color.Black;

            btn7_Matrix.BackColor = Color.White;
            btn7_Matrix.ForeColor = Color.Black;
            btn8_Matrix.BackColor = Color.White;
            btn8_Matrix.ForeColor = Color.Black;
            btn9_Matrix.BackColor = Color.White;
            btn9_Matrix.ForeColor = Color.Black;

            Turn = 1;
            Count_Matrix_spaces = 0;
        }
        
        
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void lbl_Player1_Click(object sender, EventArgs e)
        {
            lbl_Player1.Text = "Probando";
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
        

    }
}