﻿namespace tic_tac_toc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn1_Matrix = new System.Windows.Forms.Button();
            this.btn2_Matrix = new System.Windows.Forms.Button();
            this.btn3_Matrix = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.btn4_Matrix = new System.Windows.Forms.Button();
            this.btn5_Matrix = new System.Windows.Forms.Button();
            this.btn6_Matrix = new System.Windows.Forms.Button();
            this.btn7_Matrix = new System.Windows.Forms.Button();
            this.btn8_Matrix = new System.Windows.Forms.Button();
            this.btn9_Matrix = new System.Windows.Forms.Button();
            this.btn_Reset = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_Player1 = new System.Windows.Forms.Label();
            this.lbl_score = new System.Windows.Forms.Label();
            this.lbl_Player2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn1_Matrix
            // 
            this.btn1_Matrix.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn1_Matrix.Location = new System.Drawing.Point(106, 74);
            this.btn1_Matrix.Name = "btn1_Matrix";
            this.btn1_Matrix.Size = new System.Drawing.Size(105, 90);
            this.btn1_Matrix.TabIndex = 0;
            this.btn1_Matrix.UseVisualStyleBackColor = true;
            this.btn1_Matrix.Click += new System.EventHandler(this.btn1_Matrix_Click);
            // 
            // btn2_Matrix
            // 
            this.btn2_Matrix.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn2_Matrix.Location = new System.Drawing.Point(217, 74);
            this.btn2_Matrix.Name = "btn2_Matrix";
            this.btn2_Matrix.Size = new System.Drawing.Size(95, 90);
            this.btn2_Matrix.TabIndex = 1;
            this.btn2_Matrix.UseVisualStyleBackColor = true;
            this.btn2_Matrix.Click += new System.EventHandler(this.btn2_Matrix_Click);
            // 
            // btn3_Matrix
            // 
            this.btn3_Matrix.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn3_Matrix.Location = new System.Drawing.Point(318, 74);
            this.btn3_Matrix.Name = "btn3_Matrix";
            this.btn3_Matrix.Size = new System.Drawing.Size(100, 90);
            this.btn3_Matrix.TabIndex = 2;
            this.btn3_Matrix.UseVisualStyleBackColor = true;
            this.btn3_Matrix.Click += new System.EventHandler(this.button3_Click);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Berlin Sans FB", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(76, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(531, 46);
            this.label1.TabIndex = 3;
            this.label1.Text = "Welcome to Tic Tac Toe Game";
            // 
            // btn4_Matrix
            // 
            this.btn4_Matrix.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn4_Matrix.Location = new System.Drawing.Point(106, 170);
            this.btn4_Matrix.Name = "btn4_Matrix";
            this.btn4_Matrix.Size = new System.Drawing.Size(105, 95);
            this.btn4_Matrix.TabIndex = 4;
            this.btn4_Matrix.UseVisualStyleBackColor = true;
            this.btn4_Matrix.Click += new System.EventHandler(this.btn4_Matrix_Click);
            // 
            // btn5_Matrix
            // 
            this.btn5_Matrix.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn5_Matrix.Location = new System.Drawing.Point(218, 170);
            this.btn5_Matrix.Name = "btn5_Matrix";
            this.btn5_Matrix.Size = new System.Drawing.Size(94, 95);
            this.btn5_Matrix.TabIndex = 5;
            this.btn5_Matrix.UseVisualStyleBackColor = true;
            this.btn5_Matrix.Click += new System.EventHandler(this.btn5_Matrix_Click);
            // 
            // btn6_Matrix
            // 
            this.btn6_Matrix.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn6_Matrix.Location = new System.Drawing.Point(318, 170);
            this.btn6_Matrix.Name = "btn6_Matrix";
            this.btn6_Matrix.Size = new System.Drawing.Size(100, 95);
            this.btn6_Matrix.TabIndex = 6;
            this.btn6_Matrix.UseVisualStyleBackColor = true;
            this.btn6_Matrix.Click += new System.EventHandler(this.btn6_Matrix_Click);
            // 
            // btn7_Matrix
            // 
            this.btn7_Matrix.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn7_Matrix.Location = new System.Drawing.Point(106, 271);
            this.btn7_Matrix.Name = "btn7_Matrix";
            this.btn7_Matrix.Size = new System.Drawing.Size(105, 88);
            this.btn7_Matrix.TabIndex = 7;
            this.btn7_Matrix.UseVisualStyleBackColor = true;
            this.btn7_Matrix.Click += new System.EventHandler(this.btn7_Matrix_Click);
            // 
            // btn8_Matrix
            // 
            this.btn8_Matrix.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn8_Matrix.Location = new System.Drawing.Point(218, 271);
            this.btn8_Matrix.Name = "btn8_Matrix";
            this.btn8_Matrix.Size = new System.Drawing.Size(94, 88);
            this.btn8_Matrix.TabIndex = 8;
            this.btn8_Matrix.UseVisualStyleBackColor = true;
            this.btn8_Matrix.Click += new System.EventHandler(this.btn8_Matrix_Click);
            // 
            // btn9_Matrix
            // 
            this.btn9_Matrix.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn9_Matrix.Location = new System.Drawing.Point(318, 271);
            this.btn9_Matrix.Name = "btn9_Matrix";
            this.btn9_Matrix.Size = new System.Drawing.Size(100, 88);
            this.btn9_Matrix.TabIndex = 9;
            this.btn9_Matrix.UseVisualStyleBackColor = true;
            this.btn9_Matrix.Click += new System.EventHandler(this.btn9_Matrix_Click);
            // 
            // btn_Reset
            // 
            this.btn_Reset.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_Reset.Location = new System.Drawing.Point(572, 271);
            this.btn_Reset.Name = "btn_Reset";
            this.btn_Reset.Size = new System.Drawing.Size(114, 35);
            this.btn_Reset.TabIndex = 12;
            this.btn_Reset.Text = "Reset";
            this.btn_Reset.UseVisualStyleBackColor = true;
            this.btn_Reset.Click += new System.EventHandler(this.btn_Reset_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Visby CF Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(498, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 19);
            this.label2.TabIndex = 13;
            this.label2.Text = "Player 1";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Visby CF Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(648, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 19);
            this.label3.TabIndex = 14;
            this.label3.Text = "Player 2";
            // 
            // lbl_Player1
            // 
            this.lbl_Player1.AutoSize = true;
            this.lbl_Player1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_Player1.Location = new System.Drawing.Point(498, 183);
            this.lbl_Player1.Name = "lbl_Player1";
            this.lbl_Player1.Size = new System.Drawing.Size(23, 25);
            this.lbl_Player1.TabIndex = 15;
            this.lbl_Player1.Text = "0";
            this.lbl_Player1.Click += new System.EventHandler(this.lbl_Player1_Click);
            // 
            // lbl_score
            // 
            this.lbl_score.AutoSize = true;
            this.lbl_score.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_score.ForeColor = System.Drawing.Color.Blue;
            this.lbl_score.Location = new System.Drawing.Point(498, 95);
            this.lbl_score.Name = "lbl_score";
            this.lbl_score.Size = new System.Drawing.Size(235, 40);
            this.lbl_score.TabIndex = 16;
            this.lbl_score.Text = "SCORE PLAYERS";
            // 
            // lbl_Player2
            // 
            this.lbl_Player2.AutoSize = true;
            this.lbl_Player2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_Player2.Location = new System.Drawing.Point(648, 183);
            this.lbl_Player2.Name = "lbl_Player2";
            this.lbl_Player2.Size = new System.Drawing.Size(23, 25);
            this.lbl_Player2.TabIndex = 17;
            this.lbl_Player2.Text = "0";
            this.lbl_Player2.Click += new System.EventHandler(this.label4_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl_Player2);
            this.Controls.Add(this.lbl_score);
            this.Controls.Add(this.lbl_Player1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_Reset);
            this.Controls.Add(this.btn9_Matrix);
            this.Controls.Add(this.btn8_Matrix);
            this.Controls.Add(this.btn7_Matrix);
            this.Controls.Add(this.btn6_Matrix);
            this.Controls.Add(this.btn5_Matrix);
            this.Controls.Add(this.btn4_Matrix);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn3_Matrix);
            this.Controls.Add(this.btn2_Matrix);
            this.Controls.Add(this.btn1_Matrix);
            this.ForeColor = System.Drawing.Color.Blue;
            this.Name = "Form1";
            this.Text = "Welcome to Tic Tac Toe Game";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btn1_Matrix;
        private Button btn2_Matrix;
        private Button btn3_Matrix;
        private ImageList imageList1;
        public Label label1;
        private Button btn4_Matrix;
        private Button btn5_Matrix;
        private Button btn6_Matrix;
        private Button btn7_Matrix;
        private Button btn8_Matrix;
        private Button btn9_Matrix;
        private Button btn_Reset;
        private Label label2;
        private Label label3;
        private Label lbl_Player1;
        private Label lbl_score;
        private Label lbl_Player2;
    }
}